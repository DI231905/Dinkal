const MAPBOX_KEY = "";
const OPENCAGE_KEY = "";
const APP_DATA = "eng1003A2-21S2-Data";
// Any other local storage keys should be defined after this line